# 
# Final Project (BA)
# Valorant Map Win Rate
#

#install.packages("ggplot2")
#install.packages("dplyr")
#library(dplyr)
#library(ggplot2)

# import
valDF <- read.csv("valorant_games.csv")
attach(valDF)

#
# cleaning / wrangling
#

head(valDF) 
valDF[is.na(valDF)] # no NA values
colnames(valDF)
nrow(valDF)

# factorize rank column
valDF$rank <- factor(valDF$rank, levels = c("Radiant", 
                                "Immortal 3", "Immortal 2", "Immortal 1", 
                                "Ascendant 3", "Ascendant 2", "Ascendant 1", 
                                "Diamond 3", "Diamond 2", "Diamond 1", 
                                "Platinum 3", "Platinum 2", "Platinum 1", 
                                "Gold 3", "Gold 2", "Gold 1", 
                                "Silver 3", "Silver 2", "Silver 1",
                                "Bronze 3", "Bronze 2", "Bronze 1",
                                "Iron 3", "Iron 2", "Iron 1",
                                "Unranked", "Placement"
                                ))


# check features
str(valDF)

#
# data exploration
#

# stats
summary(valDF)

# graphs
rankColors <- c("#eee5ae", 
                "#92376c", "#ad3671", "#b63e66", 
                "#187a46", "#21a65f", "#77c49c", 
                "#a770f1", "#bf6dd6", "#f096f4", 
                "#297280", "#389faf", "#53d3df", 
                "#d5871e", "#eac34b", "#f2ebb4", 
                "#aaaead", "#cdd3d1", "#f3faf7", 
                "#513804", "#a5855d", "#cab692", 
                "#2d2d2d", "#4f4f4f", "#919193", 
                "#f7fbfc", "#243649"
                )

names(rankColors) <- levels(rank)

agentColors <- c("#CFD9E4", "#426CFB", "#992900", "#7C5046", "#FC874A", 
                 "#F5D074", "#62AB3C", "#3B3B91", "#383F51", "#A4595A", 
                 "#7D4BFF"
                 )

names(agentColors) <- unique(agent)

# kdr freq
ggplot(valDF, aes(kdr)) + 
  geom_histogram(binwidth = 0.5, fill = "red") + 
  labs(title = "K/D Ratio Frequency")

# average kd by rank
ggplot(valDF, aes(rank, kdr, fill = rank)) +
  stat_summary(fun = "mean", geom = "bar") +
  labs(title = "Mean K/D Ratio by Rank") +
  scale_fill_manual(values = rankColors)

# agent selection
ggplot(valDF, aes("", agent, fill = agent)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y", start = 0) +
  labs(title = "Agent Usage") +
  scale_fill_manual(values = agentColors) +
  theme_void()

detach(valDF)

# 
# statistical analysis
# 

# killjoy, cypher subset
kjCyhperDF <- valDF[valDF$agent %in% c("Killjoy", "Cypher"), ]
attach(kjCyhperDF)

# verifying row number
nrow(kjCyhperDF)

# contingency table
conTab <- table(agent, outcome)

# chi square
chisq.test(conTab)

# more graphs (chi square)
ggplot(as.data.frame(conTab), aes(outcome, Freq, fill = outcome)) +
  geom_point(position = "dodge") +
  facet_grid(cols = vars(agent))

as.data.frame(conTab)
